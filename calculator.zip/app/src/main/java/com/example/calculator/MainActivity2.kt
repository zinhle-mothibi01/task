package com.example.calculator

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    private lateinit var numbersEditText: EditText
    private lateinit var numbersTextView: TextView

    private val numbersArray = IntArray(10)
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        numbersEditText = findViewById(R.id.editTextNumberSigned)
        numbersTextView = findViewById(R.id.textView4)

        val addButton: Button = findViewById(R.id.button7)
        addButton.setOnClickListener {
            addNumber()
        }

        val clearButton: Button = findViewById(R.id.button8)
        clearButton.setOnClickListener {
            clearNumbers()
        }

        val calculateAverageButton: Button = findViewById(R.id.button9)
        calculateAverageButton.setOnClickListener {
            calculateAverage()
        }

        val findMinMaxButton: Button = findViewById(R.id.button10)
        findMinMaxButton.setOnClickListener {
            findMinMax()
        }
    }

    private fun addNumber() {
        val numberStr = numbersEditText.text.toString()
        if (numberStr.isNotEmpty()) {
            val number = numberStr.toInt()
            if (currentIndex < 10) {
                numbersArray[currentIndex] = number
                currentIndex++
                updateNumbersTextView()
            } else {
                showErrorMessage("You can't enter more than 10 numbers.")
            }
        }
    }

    private fun clearNumbers() {
        currentIndex = 0
        for (i in numbersArray.indices) {
            numbersArray[i] = 0
        }
        updateNumbersTextView()
    }

    private fun updateNumbersTextView() {
        val numbersString = numbersArray.filter { it != 0 }.joinToString(", ")
        numbersTextView.text = "Numbers: $numbersString"
    }

    private fun calculateAverage() {
        if (currentIndex > 0) {
            val sum = numbersArray.take(currentIndex).sum()
            val average = sum.toDouble() / currentIndex
            val resultTextView: TextView = findViewById(R.id.textView6)
            resultTextView.text = "The average is $average"
        } else {
            showErrorMessage("Please enter numbers before calculating the average.")
        }
    }

    private fun findMinMax() {
        if (currentIndex > 0) {
            val min = numbersArray.take(currentIndex).minOrNull() ?: 0
            val max = numbersArray.take(currentIndex).maxOrNull() ?: 0
            val resultTextView: TextView = findViewById(R.id.textView6)
            resultTextView.text = "Min= $min   and    Max= $max"
        } else {
            showErrorMessage("Please enter numbers before finding the min and max.")
        }
    }

    private fun showErrorMessage(message: String) {
        val resultTextView: TextView = findViewById(R.id.textView6)
        resultTextView.text = message
    }
}
