package com.example.calculator

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1EditText = findViewById(R.id.num1)
        num2EditText = findViewById(R.id.num2)
        resultTextView = findViewById(R.id.Answer1)

        val addButton: Button = findViewById(R.id.button)
        addButton.setOnClickListener {
            calculate('+')
        }

        val subtractButton: Button = findViewById(R.id.button4)
        subtractButton.setOnClickListener {
            calculate('-')
        }

        val multiplyButton: Button = findViewById(R.id.button2)
        multiplyButton.setOnClickListener {
            calculate('*')
        }

        val divideButton: Button = findViewById(R.id.button3)
        divideButton.setOnClickListener {
            calculate('/')
        }

        val buttonPower: Button = findViewById(R.id.button6)
        buttonPower.setOnClickListener {
            calculate('^')
        }

        val buttonSquareRoot: Button = findViewById(R.id.button5)
        buttonSquareRoot.setOnClickListener {
            calculate('√')
        }

        val statsButton: Button = findViewById(R.id.button11)
        statsButton.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }
    }

    private fun calculate(operator: Char) {
        val num1Str = num1EditText.text.toString()
        val num2Str = num2EditText.text.toString()

        if (num1Str.isNotEmpty() && num2Str.isNotEmpty()) {
            val num1 = num1Str.toDouble()
            val num2 = num2Str.toDouble()
            var result = 0.0

            when (operator) {
                '+' -> result = num1 + num2
                '-' -> result = num1 - num2
                '*' -> result = num1 * num2
                '/' -> {
                    if (num2 != 0.0) {
                        result = num1 / num2
                    } else {
                        resultTextView.text = "Cannot divide by zero"
                        return
                    }
                }
                '√' -> {
                    if (num2 >= 0) {
                        result = sqrt(num2)
                    } else {
                        resultTextView.text = "Invalid input for square root"
                        return
                    }
                }
                '^' -> {
                    result = num1.pow(num2)
                }
                else -> {
                    resultTextView.text = "Invalid Operator"
                    return
                }
            }

            resultTextView.text = when (operator) {
                '+' -> " $num1 + $num2 = $result"
                '-' -> " $num1 - $num2 = $result"
                '*' -> " $num1 × $num2 = $result"
                '/' -> " $num1 ÷ $num2 = $result"
                '√' -> " √$num1 = $result"
                '^' -> " $num1 ^ $num2 = $result"
                else -> "Invalid Operator"
            }
        } else {
            resultTextView.text = "Please enter numbers in both fields"
        }
    }
}
