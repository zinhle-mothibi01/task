// StatisticsActivity.kt
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatisticsActivity : AppCompatActivity() {

    private lateinit var numbers: MutableList<Int>
    private lateinit var numbersTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        numbers = mutableListOf()
        numbersTextView = findViewById(R.id.numbersTextView)

        val inputNumber: EditText = findViewById(R.id.inputNumber)
        val addButton: Button = findViewById(R.id.addButton)
        val clearButton: Button = findViewById(R.id.clearButton)
        val calculateAverageButton: Button = findViewById(R.id.calculateAverageButton)

        addButton.setOnClickListener {
            addNumber(inputNumber.text.toString())
        }

        clearButton.setOnClickListener {
            clearNumbers()
        }

        calculateAverageButton.setOnClickListener {
            calculateAverage()
        }
    }

    private fun addNumber(input: String) {
        if (input.isNotEmpty()) {
            val number = input.toInt()
            if (numbers.size < 10) {
                numbers.add(number)
                updateNumbersTextView()
            } else {
                // Notify the user that only 10 numbers are allowed
            }
            inputNumber.text.clear()
        }
    }

    private fun clearNumbers() {
        numbers.clear()
        updateNumbersTextView()
    }

    private fun calculateAverage() {
        if (numbers.isNotEmpty()) {
            val sum = numbers.sum()
            val average = sum.toDouble() / numbers.size
            // Display the average or use it as needed
        } else {
            // Handle the case where no numbers are entered
        }
    }

    private fun updateNumbersTextView() {
        numbersTextView.text = "Numbers: ${numbers.joinToString(", ")}"
    }
}
